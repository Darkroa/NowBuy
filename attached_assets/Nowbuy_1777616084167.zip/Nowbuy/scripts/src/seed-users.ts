import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

const SEED = [
  { email: "admin@nowbuy.com", name: "Ada Admin", password: "admin1234", role: "admin" },
  { email: "pm@nowbuy.com", name: "Pat Manager", password: "pm123456", role: "pm" },
];

async function main() {
  for (const u of SEED) {
    const [existing] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, u.email));
    const passwordHash = await bcrypt.hash(u.password, 10);
    if (existing) {
      await db
        .update(usersTable)
        .set({ name: u.name, passwordHash, role: u.role })
        .where(eq(usersTable.email, u.email));
      console.log(`Updated ${u.email} (${u.role})`);
    } else {
      await db.insert(usersTable).values({
        email: u.email,
        name: u.name,
        passwordHash,
        role: u.role,
      });
      console.log(`Created ${u.email} (${u.role})`);
    }
  }
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
