import { db, productsTable } from "@workspace/db";

type SeedProduct = {
  name: string;
  description: string;
  category: string;
  price: number;
  imageUrl: string;
  rating: number;
  stock: number;
  sellerName: string;
  tags: string[];
};

const PRODUCTS: SeedProduct[] = [
  // Footwear
  {
    name: "Onyx Runner",
    description: "Lightweight black running shoe with breathable knit upper and responsive foam midsole. Perfect for daily 5K runs.",
    category: "footwear",
    price: 119.0,
    imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80",
    rating: 4.7,
    stock: 32,
    sellerName: "Marathon Goods",
    tags: ["black", "running", "shoes", "size 10", "athletic"],
  },
  {
    name: "Cloud Trainer Pro",
    description: "Cushioned all-day trainer in soft white. Comfortable enough for the gym and the commute.",
    category: "footwear",
    price: 145.0,
    imageUrl: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&q=80",
    rating: 4.6,
    stock: 18,
    sellerName: "Marathon Goods",
    tags: ["white", "training", "shoes", "athletic"],
  },
  {
    name: "Heritage Leather Boot",
    description: "Hand-stitched full-grain leather boot with Goodyear welt construction. Made to last decades.",
    category: "footwear",
    price: 320.0,
    imageUrl: "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=800&q=80",
    rating: 4.9,
    stock: 12,
    sellerName: "Northfield Bootworks",
    tags: ["brown", "leather", "boots", "winter"],
  },
  // Audio
  {
    name: "Halo Wireless Headphones",
    description: "Studio-grade noise-canceling over-ear headphones with 40-hour battery life and balanced sound profile.",
    category: "audio",
    price: 279.0,
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
    rating: 4.8,
    stock: 24,
    sellerName: "Sonic Atelier",
    tags: ["wireless", "headphones", "noise-canceling", "audio"],
  },
  {
    name: "Pebble Earbuds",
    description: "Tiny true-wireless earbuds with surprisingly punchy bass and a charging case the size of a coin.",
    category: "audio",
    price: 89.0,
    imageUrl: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=800&q=80",
    rating: 4.4,
    stock: 60,
    sellerName: "Sonic Atelier",
    tags: ["earbuds", "wireless", "audio", "compact"],
  },
  // Home
  {
    name: "Crescent Desk Lamp",
    description: "Minimalist brass desk lamp with warm dimmable LED. Adds a soft glow to any workspace.",
    category: "home",
    price: 158.0,
    imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&q=80",
    rating: 4.7,
    stock: 22,
    sellerName: "Studio North",
    tags: ["lamp", "desk", "minimalist", "lighting"],
  },
  {
    name: "Hand-thrown Coffee Mug",
    description: "Stoneware mug with reactive matte glaze. Each one is slightly different — that is the point.",
    category: "home",
    price: 28.0,
    imageUrl: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=800&q=80",
    rating: 4.9,
    stock: 80,
    sellerName: "Field Ceramics",
    tags: ["mug", "ceramic", "coffee", "kitchen"],
  },
  {
    name: "Linen Throw Blanket",
    description: "Stonewashed linen throw in oat. Lightweight enough for summer, layered for winter.",
    category: "home",
    price: 95.0,
    imageUrl: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&q=80",
    rating: 4.5,
    stock: 40,
    sellerName: "Field & Loom",
    tags: ["blanket", "linen", "home", "decor"],
  },
  // Apparel
  {
    name: "Garment-dyed Linen Shirt",
    description: "Relaxed-fit linen button-up in faded sage. Goes from beach to dinner without a thought.",
    category: "apparel",
    price: 138.0,
    imageUrl: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&q=80",
    rating: 4.6,
    stock: 35,
    sellerName: "Common Thread",
    tags: ["shirt", "linen", "summer", "apparel"],
  },
  {
    name: "Heavyweight Crewneck Tee",
    description: "260gsm boxy-fit cotton tee that holds its shape after 100 washes.",
    category: "apparel",
    price: 48.0,
    imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=80",
    rating: 4.4,
    stock: 120,
    sellerName: "Common Thread",
    tags: ["tee", "shirt", "cotton", "basics", "apparel"],
  },
  // Accessories
  {
    name: "Bifold Leather Wallet",
    description: "Slim vegetable-tanned leather wallet that develops a beautiful patina over time.",
    category: "accessories",
    price: 78.0,
    imageUrl: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&q=80",
    rating: 4.7,
    stock: 50,
    sellerName: "Northfield Bootworks",
    tags: ["wallet", "leather", "accessories"],
  },
  {
    name: "Field Watch — Black",
    description: "Mechanical 38mm field watch with sapphire crystal and 100m water resistance. Black dial, leather strap.",
    category: "accessories",
    price: 449.0,
    imageUrl: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&q=80",
    rating: 4.8,
    stock: 8,
    sellerName: "Meridian Watches",
    tags: ["watch", "mechanical", "black", "accessories"],
  },
  // Tech
  {
    name: "Slate Mechanical Keyboard",
    description: "Hot-swappable 65% mechanical keyboard with linear switches and PBT keycaps.",
    category: "tech",
    price: 189.0,
    imageUrl: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&q=80",
    rating: 4.7,
    stock: 26,
    sellerName: "Quiet Systems",
    tags: ["keyboard", "mechanical", "desk", "tech"],
  },
  {
    name: "Walnut Phone Stand",
    description: "Single-piece walnut phone stand machined to fit any modern phone with or without a case.",
    category: "tech",
    price: 42.0,
    imageUrl: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&q=80",
    rating: 4.5,
    stock: 90,
    sellerName: "Quiet Systems",
    tags: ["phone", "wood", "desk", "tech"],
  },
  // Bags
  {
    name: "Field Tote",
    description: "Waxed canvas tote with leather handles. Holds a laptop, a book, and a baguette.",
    category: "bags",
    price: 168.0,
    imageUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&q=80",
    rating: 4.6,
    stock: 38,
    sellerName: "Field & Loom",
    tags: ["tote", "bag", "canvas", "everyday"],
  },
  {
    name: "Weekender Duffel",
    description: "Two-day weekender in oiled leather. Carries enough for a long weekend without checking a bag.",
    category: "bags",
    price: 395.0,
    imageUrl: "https://images.unsplash.com/photo-1547949003-9792a18a2601?w=800&q=80",
    rating: 4.8,
    stock: 14,
    sellerName: "Northfield Bootworks",
    tags: ["duffel", "weekender", "leather", "travel"],
  },
];

async function main() {
  const existing = await db.select().from(productsTable).limit(1);
  if (existing.length > 0) {
    console.log("Products already seeded — skipping.");
    process.exit(0);
  }
  await db.insert(productsTable).values(
    PRODUCTS.map((p) => ({
      name: p.name,
      description: p.description,
      category: p.category,
      price: p.price,
      currency: "USD",
      imageUrl: p.imageUrl,
      rating: p.rating,
      stock: p.stock,
      sellerName: p.sellerName,
      tags: p.tags,
    })),
  );
  console.log(`Seeded ${PRODUCTS.length} products.`);
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
