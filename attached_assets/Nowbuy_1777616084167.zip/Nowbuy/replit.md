# NowBuy

AI-powered ecommerce storefront MVP. Buyers chat with an AI shopping assistant
that finds products and can place orders for them after explicit confirmation.

## Architecture

- **artifacts/storefront** — React + Vite + Tailwind storefront (path `/`).
  - Pages: home, products, product detail, assistant (AI chat), cart, orders, order detail.
  - Floating "Ask AI" pill links to `/assistant` from every other page.
  - Uses generated hooks from `@workspace/api-client-react`.
- **artifacts/api-server** — Express API (path `/api`).
  - Routes: products, cart, orders, chat (with OpenAI tool calling).
  - Cookie-based session id (`nb_session`) — no auth in MVP.
  - AI uses three tools: `search_products`, `add_to_cart`, `place_order`.
    `place_order` only fires when the request includes `confirmOrder=true` and
    `shippingAddress`.
- **lib/db** — Drizzle schema for `products`, `cart_items`, `orders`,
  `chat_messages` (all keyed by `session_id` text column).
- **lib/api-spec** — OpenAPI source of truth; codegen produces zod + react-query
  hooks.

## OpenAI integration

Uses the Replit AI Integrations proxy (no API key managed here). Model:
`gpt-5.4` with `max_completion_tokens` set per request. Imported via
`openai` from `@workspace/integrations-openai-ai-server`.

Two template files were patched:
- `lib/integrations-openai-ai-server/src/batch/utils.ts` — use named
  `AbortError` from `p-retry` instead of `pRetry.AbortError`.
- `lib/integrations-openai-ai-server/src/image/client.ts` — null-check
  `response.data` from images.generate/edit.

## Database

Provisioned Postgres (DATABASE_URL is set). Seeded 16 products via
`scripts/src/seed-nowbuy.ts`. Re-run with:

```
pnpm --filter @workspace/scripts exec tsx ./src/seed-nowbuy.ts
```

(Skips if products already exist.)

## Codegen

After editing `lib/api-spec/openapi.yaml`:

```
pnpm --filter @workspace/api-spec run codegen
```

Note: orval generates request body schemas as `…Body` and request params as
`…Params`. Avoid naming OpenAPI components `…Body` / `…Params` (collides with
generated identifiers).

## Future work

- Buyer auth (currently session-cookie only).
- Seller dashboard (product CRUD, order management).
- Admin moderation.
- Real payment processing.
